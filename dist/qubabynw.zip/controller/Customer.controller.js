sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("qubabynw.controller.Customer",{onInit:function(){}})});
//# sourceMappingURL=Customer.controller.js.map